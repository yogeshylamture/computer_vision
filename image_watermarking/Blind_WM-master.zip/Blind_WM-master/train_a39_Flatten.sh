CUDA_VISIBLE_DEVICES='2' python3 -u main.py  \
	--cfg configs/DeConv_WMFlatten.yaml  \
	--bs 20  \
	--nw 4  \
	--name a39_7_Flatten \

