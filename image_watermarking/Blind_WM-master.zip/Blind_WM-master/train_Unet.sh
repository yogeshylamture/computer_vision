CUDA_VISIBLE_DEVICES='0' python3 -u main.py  \
	--cfg configs/U_NET.yaml  \
	--bs 20  \
	--nw 4  \
	--name test_a39_1_Unet_MSE_MSE \

