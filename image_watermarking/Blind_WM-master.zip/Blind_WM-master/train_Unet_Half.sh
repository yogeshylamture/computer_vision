CUDA_VISIBLE_DEVICES='0' python3 -u main.py  \
	--cfg configs/U_NET_Half.yaml  \
	--bs 20  \
	--nw 4  \
	--name test_U_NET_Half \

