CUDA_VISIBLE_DEVICES='0' python3 -u main.py  \
	--cfg configs/Hidden.yaml  \
	--bs 10  \
	--nw 4  \
	--name a34_3_Hidden_MSE \

