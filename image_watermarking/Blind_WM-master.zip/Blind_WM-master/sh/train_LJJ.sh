CUDA_VISIBLE_DEVICES='2' python3 -u main.py  \
	--cfg configs/LJJ_Net.yaml  \
	--bs 20  \
	--nw 4  \
	--name a38_4_SSIM_Cross_Residual \

