CUDA_VISIBLE_DEVICES='0' python3 -u main.py  \
	--cfg configs/Hidden_L1.yaml  \
	--bs 8  \
	--nw 4  \
	--name a_29_3_Hidden_L1 \

