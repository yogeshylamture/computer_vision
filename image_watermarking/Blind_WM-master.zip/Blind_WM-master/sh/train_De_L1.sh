CUDA_VISIBLE_DEVICES='1' python3 -u main.py  \
	--cfg configs/DeConv_L1.yaml  \
	--bs 8  \
	--nw 4  \
	--name DeConv_L1 \

