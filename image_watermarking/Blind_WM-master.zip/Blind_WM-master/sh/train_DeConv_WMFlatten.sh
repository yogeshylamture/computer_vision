CUDA_VISIBLE_DEVICES='3' python3 -u main.py  \
	--cfg configs/DeConv_WMFlatten_L1.yaml  \
	--bs 8  \
	--nw 4  \
	--name a32_train_DeConv_WMFlatten_L1 \

