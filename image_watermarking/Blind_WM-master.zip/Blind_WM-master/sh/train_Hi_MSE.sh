CUDA_VISIBLE_DEVICES='1' python3 -u main.py  \
	--cfg configs/Hidden_MSE.yaml  \
	--bs 8  \
	--nw 4  \
	--name a29_4_Hidden_MSE \

