CUDA_VISIBLE_DEVICES='0' python3 -u main.py  \
	--cfg configs/DeConv_MSE.yaml  \
	--bs 20  \
	--nw 4  \
	--name DeConv_MSE \

