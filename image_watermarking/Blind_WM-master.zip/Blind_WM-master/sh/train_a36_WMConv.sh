CUDA_VISIBLE_DEVICES='2' python3 -u main.py  \
	--cfg configs/IMGConv_WMDeConv.yaml  \
	--bs 20  \
	--nw 4  \
	--name test_WMConv \

