CUDA_VISIBLE_DEVICES='3' python3 -u main.py  \
	--cfg configs/DeConv_WMConv.yaml  \
	--bs 20  \
	--nw 4  \
	--name a31_3_DeConv_WMConv_MSE \

