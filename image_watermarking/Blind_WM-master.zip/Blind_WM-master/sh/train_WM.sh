CUDA_VISIBLE_DEVICES='1' python3 -u main.py  \
	--cfg configs/DeConv_DeConv_WM.yaml  \
	--bs 8  \
	--nw 4  \
	--name DeConv_DeConv_WM \

