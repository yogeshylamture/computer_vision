# DWT-DCT-Digital-Image-Watermarking
a digital image watermarking algorithm based on combining two transforms; DWT and DCT. Watermarking is done by altering the wavelets coefficients of carefully selected DWT sub-bands, followed by the application of the DCT transform on the selected sub-bands.
