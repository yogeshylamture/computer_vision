# Blind-image-watermarking-technique-based-on-differential-embedding-in-DWT-and-DCT-domains
unofficial python implementation of the paper [Blind image watermarking technique based on differential embedding in DWT and DCT domains](https://asp-eurasipjournals.springeropen.com/articles/10.1186/s13634-015-0239-5)

