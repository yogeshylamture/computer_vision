# Steganographic-Watermarking-Key-Based
Final year undergrad project. High fidelity algorithm for watermarking both text and images on images using MATLAB.
