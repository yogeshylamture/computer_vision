# SecretInk
Image in Image steganography in the frequency domian using MATLAB. Secret image encrypted with RSA and embedded in host image using Discrete Cosine Transform(DCT) and Discrete Wavelet Transform (DWT) and watermarking is performed.
