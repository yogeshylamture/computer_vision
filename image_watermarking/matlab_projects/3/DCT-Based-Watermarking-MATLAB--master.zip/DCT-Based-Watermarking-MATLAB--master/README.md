# DCT-Based-Watermarking-MATLAB-
This code will help you watermark an image using DCT and remove the watermark and present the original image using IDCT.
