function enable_watermark(handles)

        set(handles.popup_scheme,'Enable','on');
        set(handles.popup_domain,'Enable','on');
        set(handles.popup_embed_watermark,'Enable','on');
        set(handles.popup_detect_watermark,'Enable','on');
        
        set(handles.btn_next_input,'Enable','on');

