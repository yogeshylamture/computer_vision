function disable_attack(handles)

    set(handles.popup_profile,'Enable','off');
    
    set(handles.tab_geometric,'Visible','off');
    set(handles.tab_compression,'Visible','off');
    set(handles.tab_noise,'Visible','off');
    set(handles.tab_color_manipulation,'Visible','off');
    set(handles.tab_enhancements,'Visible','off');
    
    set(handles.btn_tab_geometric,'Visible','off');
    set(handles.btn_tab_compression,'Visible','off');
    set(handles.btn_tab_noise,'Visible','off');
    set(handles.btn_tab_color_manipulation,'Visible','off');
    set(handles.btn_tab_enhancements,'Visible','off');
    
    
        