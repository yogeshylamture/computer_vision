function enable_benchmark(handles)

        set(handles.btn_benchmark,'Enable','on');
        set(handles.radiobutton_matlab,'Enable','on');
        set(handles.radiobutton_basic_pdf,'Enable','on');
        set(handles.radiobutton_basic_html,'Enable','on');
        set(handles.radiobutton_basic_doc,'Enable','on');
        set(handles.radiobutton_advanced_pdf,'Enable','on');
        set(handles.radiobutton_advanced_html,'Enable','on');
        set(handles.radiobutton_advanced_doc,'Enable','on');
        set(handles.btn_view_results,'Enable','on');
        
        