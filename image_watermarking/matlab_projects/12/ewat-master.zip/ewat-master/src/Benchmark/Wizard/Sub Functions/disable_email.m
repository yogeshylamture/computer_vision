function disable_email(handles)

set(handles.btn_email_list,'Enable','off');
set(handles.btn_edit_email_list,'Enable','off');
set(handles.input_email,'Enable','off');
set(handles.input_password,'Enable','off');
set(handles.input_subject,'Enable','off');
set(handles.input_email_message,'Enable','off');
set(handles.checkbox_include_attachment,'Enable','off');
