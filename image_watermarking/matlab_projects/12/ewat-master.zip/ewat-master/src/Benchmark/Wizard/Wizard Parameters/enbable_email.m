function enable_email(handles)

set(handles.btn_email_list,'Enable','on');
set(handles.btn_edit_email_list,'Enable','on');
set(handles.input_email,'Enable','on');
set(handles.input_password,'Enable','on');
set(handles.input_subject,'Enable','on');
set(handles.input_email_message,'Enable','on');
set(handles.checkbox_include_attachment,'Enable','on');
