function disable_watermark(handles)

        
        set(handles.btn_next_input,'Enable','off');
        
        set(handles.popup_scheme,'Enable','off');
        set(handles.popup_domain,'Enable','off');
        set(handles.popup_embed_watermark,'Enable','off');
        set(handles.popup_detect_watermark,'Enable','off');
         