Start the toolbox by starting advanced_watermarking_tool.m  (also set path+ subdirs).

Should you wish to use/cite this code, feel free to contact us (tim.dams@ap.be)

If you wish to reference, please use one of the following:

*"An Image Watermarking Tutorial Tool using Matlab",
Kevin HEYLEN and Tim DAMS, Conference of Mathematics of Data/Image Pattern Recognition, Compression, and Encryption with Applications XI, SPIE, San Diego, USA, 10-14 August 2008

*"A Matlab-based tutorial environment for digital image watermarking",
Kevin HEYLEN, Tom MEESTERS, Luc VERSTREPEN and Tim DAMS
Ref: European Conference on the Use of Modern Information and Communication Technologies, Gent, Belgium, 13- 14 March 2008


Note:
This package is still being developed and should not be considered 'final' (including this text)
Feel free to use this Matlab-toolbox anyway possible. Any code copied belongs to the original authors.