# IMAGE-PROCESSING-AND-WATERMARKING-USING-MATLAB
We basically check the one who owns the image remains same or not while travelling of image from one place to other also if in case it is distorted then we check where it is tampered and try to identify that area.
