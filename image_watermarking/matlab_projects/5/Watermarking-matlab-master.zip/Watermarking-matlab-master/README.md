#         Making watermark Using **LSB** algorithm
##           **this program in matlab**

###### We use **OPAP** Algorithm to Extract the Secret image 



###### program is very Simple and easy for use 


## How i can using :
*  install matlab
*  run matlab
*  open file **Gui0.m** and run it 
*  enjoy


## if program make crach :
###### ther is becouse function caled 

```matlab 
de2bi()     %this function to convert from decimal to binary% 
```



###### this problem happend because the function doesn't exist in your matlab toolbox 
## To solve it: 
**search about problem in [mr.Google](www.google.com)**



this program build by **@moroclash** 
